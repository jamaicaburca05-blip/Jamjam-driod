document.addEventListener("DOMContentLoaded", () => {
  // Smooth scroll activation for navigation links
  const navLinks = document.querySelectorAll('.navlinks a[href^="#"]');

  navLinks.forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);

      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // Optional: Console message to confirm page load
  console.log("Gender Roles in the Philippines website loaded successfully.");
});